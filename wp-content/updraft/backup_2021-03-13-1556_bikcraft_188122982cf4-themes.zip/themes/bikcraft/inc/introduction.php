<section class="introducao-interna interna_sobre">
    <div class="container">
        <h1>Sobre</h1>
        <p>conheça mais sobre a bikcraft</p>
    </div>
</section>